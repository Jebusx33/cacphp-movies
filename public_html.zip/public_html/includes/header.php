<header>
<div class="nav-principal">
        <div class="link-logo animate__animated animate__tada ">
            <a class="logo-link" href="index.php">
            <img class="logo" src="img/film-solid.svg" alt="LOGO">
            CAC-Movies</a>
        </div>
        <nav class="nav-enlaces">
            <a class="" href="index.php#tendencias">Tendencias</a>
            <a class="" href="registrarse.php">Registrarse</a>
            <a class="" href="reg_movie.php">Registrar Pelicula</a>
             <a class="" href="list_movies.php">Lista de Peliculas</a>
            <a class="" href="reg_director.php">Registrar Director</a>
            <a class="sesion" href="login.php">Iniciar Sesión</a>
            <a class="link-mv" href="apimarvel.php">API<img src="img/Marvel_Logo.svg" alt="logo" class="logo-marvel"></a>
        </nav>
    </div>
    </header>