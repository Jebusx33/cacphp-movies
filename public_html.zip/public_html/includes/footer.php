<footer style="margin-top:10%;">
<div class="nav-footer nav-pie">
            <nav class="nav-enlaces ">
                <a class="" href="#">Terminos y Condiciones</a>
                <a class="" href="#">Preguntas Frecuentes</a>
                <a class="" href="#">Ayuda</a>
                <a class="sesion" href="login.php">Administrador de Peliculas</a>
            </nav>
          </div>
          <div class="row">
          <div class="nav-footer" style="margin-top: -1.5%;margin-bottom: -1.5%;">
                 <p>&copy 2024  Desarrollado por: </p>
            </div>
          <div class="nav-footer">       
       <p>Adrián Seri</p>
       <a href="https://github.com/adrianese" target="_blank" rel="noopener noreferrer" >
       <i class="fa fa-github" aria-hidden="true" style="margin:0 15px 0 5px; color:white; font-size:4rem;"></i>
       </a>

      <p>Jesús Arias</p> 
    
       <a href="https://www.jesusarias.com.ar" target="_blank" rel="noopener noreferrer">
       <i class="fa fa-globe" style="margin:0 15px 0 10px; color:white; font-size:4rem;"></i>
      </a>
      <p>Tobias Moreno</p>
      <a href="https://github.com/" target="_blank" rel="noopener noreferrer" >
       <i class="fa fa-github" aria-hidden="true" style="margin:0 15px 0 5px; color:white; font-size:4rem;"></i>
       </a>
      <p>Mercedes Miquelez</p>
      <a href="https://github.com/" target="_blank" rel="noopener noreferrer" >
       <i class="fa fa-github" aria-hidden="true" style="margin:0 15px 0 5px; color:white; font-size:4rem;"></i>
       </a>
      <p>Giuliano Charra Márquez </p>
      <a href="https://github.com/" target="_blank" rel="noopener noreferrer" >
       <i class="fa fa-github" aria-hidden="true" style="margin:0 15px 0 5px; color:white; font-size:4rem;"></i>
       </a>
         
    </div>
          </div>
      
    </footer>

    